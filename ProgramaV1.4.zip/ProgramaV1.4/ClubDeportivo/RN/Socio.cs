﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace RN
{
    public class Socio: Persona
    {
        private int numeroSocio;
        private String categoria;
        private List<Inscripcion> inscripcionesSocio;
        private List<Pago> pagos;




        public Socio(String a, String n, String dir, int d, String e, int t,Image im, int ns, String cat):base(a, n, dir, d, e, t,im)
        {
            numeroSocio = ns;
            categoria = cat;
            inscripcionesSocio = new List<Inscripcion>();
            pagos = new List<Pago>();
        }

        public int NumeroSocio
        {
            get
            {
                return numeroSocio;
            }
            set
            {
                numeroSocio = value;
            }
        }

        public String Categoria
        {
            get
            {
                return categoria;
            }
            set
            {
                categoria = value;
            }
        }


      
    }
}
