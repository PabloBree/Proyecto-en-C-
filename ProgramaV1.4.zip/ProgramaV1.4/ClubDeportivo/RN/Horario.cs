﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RN
{
   public class Horario
    {
        private int horaIni;
        private int horaFin;
        private int idHorario;
        private Dia diaCorrespondiente;

        public Horario(int hi, int hf, int ih, Dia d)
        {
            horaIni = hi;
            horaFin = hf;
            idHorario = ih;
            diaCorrespondiente = d;
        }

        public int HoraIni
        {
            get
            {
                return horaIni;
            }
            set
            {
                horaIni = value;
            }
        }

        public int HoraFin
        {
            get
            {
                return horaFin;
            }
            set
            {
                horaFin = value;
            }
        }

        public int IdHorario
        {
            get
            {
                return idHorario;
            }
            set
            {
                idHorario = value;
            }
        }

        

    }
}
