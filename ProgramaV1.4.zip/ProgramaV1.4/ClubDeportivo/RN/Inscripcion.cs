﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RN
{
    public class Inscripcion
    {
        private DateTime fechaInscripcion;
        private Horario horarioIns;
        private int numeroIns;


        public Inscripcion(Horario h, int ni)
        {
            fechaInscripcion = DateTime.Today;
            horarioIns = h;
            numeroIns = ni;
           

        }

        public int NumeroIns
        {
            get
            {
                return numeroIns;
            }
            set
            {
                numeroIns = value;
            }
        }

        public DateTime FechaInscipcion
        {
            get
            {
                return fechaInscripcion;
            }
            set
            {
                fechaInscripcion = value;
            }
        }
    }
}
