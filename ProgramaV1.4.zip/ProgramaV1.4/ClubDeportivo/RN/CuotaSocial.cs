﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RN
{
   public class CuotaSocial
    {
        private int idCuota;
        private static float interes;
        private float montoCuota;
        private Boolean pagado;
        private DateTime fechaVencimiento;
        private String descripcion;

       // fechaVencimiento= DateTime.sadfja(07/idCuota/this.year)

        public CuotaSocial(int id, float mc, DateTime fv)
        {
            id = idCuota;
            mc = interes;
            fechaVencimiento = fv;
        }



    }
}
