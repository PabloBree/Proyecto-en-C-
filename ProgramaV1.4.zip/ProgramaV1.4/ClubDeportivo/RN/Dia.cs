﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RN
{
  public class Dia
    {
        private String descripcionDia;
        private int idDia;
        private List<Horario> horarios;

        public Dia(String dd, int id)
        {
            descripcionDia = dd;
            idDia = id;
            horarios = new List<Horario>();
        }

        public void agregarHorario(Horario h)
        {
            horarios.Add(h);
        }

        public String DescripcionDia
        {
            get
            {
                return descripcionDia;
            }
            set
            {
                descripcionDia = value;
            }
        }
        public int IdDia
        {
            get
            {
                return idDia;
            }
            set
            {
                idDia = value;
            }
        }


    }
}
