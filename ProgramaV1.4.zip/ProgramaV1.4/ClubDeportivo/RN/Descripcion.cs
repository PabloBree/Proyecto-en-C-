﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RN
{
    public class Descripcion
    {
        private String conceptoPago;
        private float montoPago;

        public Descripcion(String cp, float mp)
        {
            conceptoPago = cp;
            montoPago = mp;
        }



        public String ConceptoPago
        {
            get
            {
                return conceptoPago;
            }
            set
            {
                conceptoPago = value;
            }
        }

        public float MontoPago
        {
            get
            {
                return montoPago;
            }
            set
            {
                montoPago = value;
            }
        }


    }
}
