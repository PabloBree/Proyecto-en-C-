﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace RN
{
    public class Profesor: Persona
    {
        private int numeroEmpleado;
        private List<ActividadDeportiva> actividadesProfesor;
        private List<Horario> horariosProfesor;

    
        public Profesor(String a, String n, String dir, int d, String e, int t,Image im, int ne):base (a,n,dir,d,e,t,im)
        {
            numeroEmpleado = ne;
            actividadesProfesor = new List<ActividadDeportiva>();
            horariosProfesor = new List<Horario>();

        }

        public int NumeroEmpleado
        {
            get
            {
                return numeroEmpleado;
            }
            set
            {
                numeroEmpleado = value;
            }
        }

        public override string ToString()
        {
            return this.Dni + "  " + this.Nombre + "  "+numeroEmpleado;
        }

    }
}
