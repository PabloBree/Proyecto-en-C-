﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;


namespace RN
{
    public abstract class Persona
    {

        private String apellido;
        private String nombre;
        private String direccion;
        private int dni;
        private String email;
        private int telefono;
        private Image imagenPersona;

        public Persona(String a, String n, String dir, int d, String e, int t, Image i)
        {
            apellido = a;
            nombre = n;
            direccion = dir;
            dni = d;
            email = e;
            telefono = t;
            imagenPersona = i;
        }

        public String Apellido
        {
            get
            {
                return apellido;
            }
            set
            {
                apellido = value;
            }
        }

        public String Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }

        public String Direccion
        {
            get
            {
                return direccion;
            }
            set
            {
                direccion = value;
            }
        }

        public int Dni
        {
            get
            {
                return dni;
            }
            set
            {
                dni = value;
            }
        }

        public String Email
        {
            get
            {
                return email;
            }
            set
            {
                email = value;
            }
        }

        public int Telefono
        {
            get
            {
                return telefono;
            }
            set
            {
                telefono = value;
            }
        }

        public Image ImagenPersona
        {
            get
            {
                return imagenPersona;
            }
            set
            {
                imagenPersona = value;
            }
        }

        public override string ToString()
        {
            return dni + "  " + nombre;
        }

    }
}
