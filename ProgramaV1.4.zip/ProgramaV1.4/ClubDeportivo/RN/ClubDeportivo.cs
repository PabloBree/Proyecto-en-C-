﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RN
{
    public class ClubDeportivo
    {
        private String direccion;
        private String email;
        private int telefono;
        private List<Pago> pagos;
        private List<ActividadDeportiva> actividades;
        private List<Persona> personas; //Preguntar 
        private List<Profesor> profesores;
        private List<SocioClub> sociosClub;
        private List<SocioActividades> sociosActividades;
        private List<Socio> socios;
        private List<Dia> dias;

        public ClubDeportivo()
        {
            actividades = new List<ActividadDeportiva>();
            personas = new List<Persona>();
            profesores=new List<Profesor>();
            pagos = new List<Pago>();
            sociosClub = new List<SocioClub>();
            sociosActividades = new List<SocioActividades>();
            dias = new List<Dia>();
            socios = new List<Socio>();
            direccion = "Marconi 4562";
            email = "ClubSitas@gmail.com";
            telefono = 44615557;

            this.cargarDias();
            
        }

        public void cargarDias()
        {
            Dia l = new Dia("Lunes", 1);
            dias.Add(l);
            Dia m = new Dia("Martes", 2);
            dias.Add(m);
            Dia x = new Dia("Miercoles", 3);
            dias.Add(x);
            Dia j = new Dia("Jueves", 4);
            dias.Add(j);
            Dia v = new Dia("Viernes", 5);
            dias.Add(v);
            Dia s = new Dia("Sabado", 6);
            dias.Add(s);

        }

        
        public int DarNumeroIdProfesor()
        {
            if (profesores.Count() == 0 )
                return (1);
            else
            {
                int i = 0;
                int max = profesores[i].NumeroEmpleado;
                for (i = 1; i < profesores.Count(); i++) 
                {
                    if (profesores[i].NumeroEmpleado > max)
                        max = profesores[i].NumeroEmpleado;
                }

                return (max + 1);
            }     
        }

        public int DarNumeroIdSocio()
        {
            if (sociosClub.Count() == 0)
                return (1);
            else
            {
                int i = 0;
                int maxSocio = sociosClub[i].NumeroSocio;
                for (i = 1; i < sociosClub.Count(); i++)
                {
                    if (sociosClub[i].NumeroSocio > maxSocio)
                        maxSocio = sociosClub[i].NumeroSocio;
                }
                return (maxSocio + 1);
            }
        }
        

        public void AgregarProfesorLista(Profesor p)
        {
            profesores.Add(p);
            personas.Add(p);
           
        }

        public void AgregarSocioClubLista(SocioClub s)
        {
            personas.Add(s);
            sociosClub.Add(s);
            socios.Add(s);

        }

        
        public void AgregarSocioActLista(SocioActividades s)
        {
            personas.Add(s);
            sociosActividades.Add(s);
            socios.Add(s);
        }

        public void AgregarActividadLista(ActividadDeportiva ad)
        {
            actividades.Add(ad);

        }

        public void EliminarProfesorLista(Profesor p)
        {
            for (int i = 0; i < profesores.Count(); i++)
            {
                if (profesores[i].NumeroEmpleado == p.NumeroEmpleado)
                    profesores.Remove(p);
            }
        }

        public void EliminarActividadLista(Socio s)
        {
            for (int i = 0; i < socios.Count(); i++)
            {
                if (socios[i].NumeroSocio == s.NumeroSocio)
                    socios.Remove(s);
            }
        }

        public void EliminarActividades(ActividadDeportiva act)
        {
            for(int i=0; i<actividades.Count(); i++)
            {
                if (actividades[i].IdActDeportiva == act.IdActDeportiva)
                    actividades.Remove(act);
            }
        }

        public List <Profesor> darListaProfesores()
        {
            return profesores;
        }

      

        public List<Socio> darListaSocios()
        {
            return socios;
        }

        public List<Dia> darDias()
        {
            return (dias);
        }


        public List<ActividadDeportiva> darActividadesDeportiva()
        {
            return actividades;
        }



    }
}
