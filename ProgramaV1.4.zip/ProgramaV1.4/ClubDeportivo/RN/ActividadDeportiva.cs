﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RN
{
    public class ActividadDeportiva
    {
        private int cantMaxPart;
        private float costoMensual;
        private float costoClase;
        private String descripcionAct;
        private int idActDeportiva;
        private List<Dia> diasActividad;


        public ActividadDeportiva(int cmp,float cm,float cc, String da, int ida)
        {
            cantMaxPart = cmp;
            costoMensual = cm;
            costoClase = cc;
            descripcionAct = da;
            idActDeportiva = ida;
            diasActividad= new List<Dia>();
        }


        public int CantMaxPart
        {
            get
            {
                return cantMaxPart;
            }
            set
            {
                cantMaxPart = value;
            }
        }

        public float CostoMensual
        {
            get
            {
                return costoMensual;
            }
            set
            {
                costoMensual = value;
            }
        }

        public float CostoClase
        {
            get
            {
                return costoClase;
            }
            set
            {
                costoClase = value;
            }
        }

        public String DescripcionAct
        {
            get
            {
                return descripcionAct;
            }
            set
            {
                descripcionAct = value;
            }
        }

        public int IdActDeportiva
        {
            get
            {
                return idActDeportiva;
            }
            set
            {
                idActDeportiva = value;
            }
        }




    }
}
