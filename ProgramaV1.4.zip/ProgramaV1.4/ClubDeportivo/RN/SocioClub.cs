﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace RN
{
   public sealed class SocioClub: Socio
    {
        private List<CuotaSocial> cuotas;


        public SocioClub(String a, String n, String dir, int d, String e, int t,Image im, int ns, String cat) : base(a, n, dir, d, e, t,im, ns, cat)
        {
            cuotas = new List<CuotaSocial>();

        }

    }
}
