﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RN
{
   public class Pago
    {
        private DateTime fechaPago;
        private int idPago;
        private float montoTotal;

        public Pago(int id, float mt)
        {
            fechaPago = DateTime.Today;
            idPago = id;
            montoTotal = mt;
        }


        public DateTime FechaPago
        {
            get
            {
                return fechaPago;
            }
            set
            {
                fechaPago = value;
            }
        }

        public int IdPago
        {
            get
            {
                return idPago;
            }
            set
            {
                idPago = value;
            }
        }

        public float MontoTotal
        {
            get
            {
                return montoTotal;
            }
            set
            {
                montoTotal = value;
            }
        }






    } 
}
