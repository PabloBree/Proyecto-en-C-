﻿namespace UI
{
    partial class Actividades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonVolverMenu = new System.Windows.Forms.Button();
            this.listBoxActividades = new System.Windows.Forms.ListBox();
            this.buttonEliminarAct = new System.Windows.Forms.Button();
            this.buttonModificarAct = new System.Windows.Forms.Button();
            this.buttonAgregarAct = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonVolverMenu
            // 
            this.buttonVolverMenu.Location = new System.Drawing.Point(944, 901);
            this.buttonVolverMenu.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonVolverMenu.Name = "buttonVolverMenu";
            this.buttonVolverMenu.Size = new System.Drawing.Size(248, 105);
            this.buttonVolverMenu.TabIndex = 9;
            this.buttonVolverMenu.Text = "Volver";
            this.buttonVolverMenu.UseVisualStyleBackColor = true;
            this.buttonVolverMenu.Click += new System.EventHandler(this.buttonVolverMenu_Click);
            // 
            // listBoxActividades
            // 
            this.listBoxActividades.FormattingEnabled = true;
            this.listBoxActividades.ItemHeight = 31;
            this.listBoxActividades.Location = new System.Drawing.Point(168, 136);
            this.listBoxActividades.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.listBoxActividades.Name = "listBoxActividades";
            this.listBoxActividades.Size = new System.Drawing.Size(1753, 438);
            this.listBoxActividades.TabIndex = 8;
            // 
            // buttonEliminarAct
            // 
            this.buttonEliminarAct.Location = new System.Drawing.Point(1509, 701);
            this.buttonEliminarAct.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonEliminarAct.Name = "buttonEliminarAct";
            this.buttonEliminarAct.Size = new System.Drawing.Size(536, 67);
            this.buttonEliminarAct.TabIndex = 7;
            this.buttonEliminarAct.Text = "Eliminar";
            this.buttonEliminarAct.UseVisualStyleBackColor = true;
            this.buttonEliminarAct.Click += new System.EventHandler(this.buttonEliminarAct_Click);
            // 
            // buttonModificarAct
            // 
            this.buttonModificarAct.Location = new System.Drawing.Point(813, 699);
            this.buttonModificarAct.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonModificarAct.Name = "buttonModificarAct";
            this.buttonModificarAct.Size = new System.Drawing.Size(536, 69);
            this.buttonModificarAct.TabIndex = 6;
            this.buttonModificarAct.Text = "Modificar";
            this.buttonModificarAct.UseVisualStyleBackColor = true;
            this.buttonModificarAct.Click += new System.EventHandler(this.buttonModificarAct_Click);
            // 
            // buttonAgregarAct
            // 
            this.buttonAgregarAct.Location = new System.Drawing.Point(80, 699);
            this.buttonAgregarAct.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonAgregarAct.Name = "buttonAgregarAct";
            this.buttonAgregarAct.Size = new System.Drawing.Size(536, 67);
            this.buttonAgregarAct.TabIndex = 5;
            this.buttonAgregarAct.Text = "Agregar";
            this.buttonAgregarAct.UseVisualStyleBackColor = true;
            this.buttonAgregarAct.Click += new System.EventHandler(this.buttonAgregarAct_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(280, 52);
            this.label1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1549, 32);
            this.label1.TabIndex = 10;
            this.label1.Text = "Estas son las actividades actualmente disponibles. Seleccione la actividad que de" +
    "sea y luego oprima una de las opciones\r\n";
            // 
            // Actividades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2133, 1073);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonVolverMenu);
            this.Controls.Add(this.listBoxActividades);
            this.Controls.Add(this.buttonEliminarAct);
            this.Controls.Add(this.buttonModificarAct);
            this.Controls.Add(this.buttonAgregarAct);
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "Actividades";
            this.Text = "ActividadDeportiva";
            this.Load += new System.EventHandler(this.Actividades_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonVolverMenu;
        private System.Windows.Forms.ListBox listBoxActividades;
        private System.Windows.Forms.Button buttonEliminarAct;
        private System.Windows.Forms.Button buttonModificarAct;
        private System.Windows.Forms.Button buttonAgregarAct;
        private System.Windows.Forms.Label label1;
    }
}