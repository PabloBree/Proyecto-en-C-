﻿namespace UI
{
    partial class ActividadNuevoHorario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelDia = new System.Windows.Forms.Label();
            this.labelHora = new System.Windows.Forms.Label();
            this.labelFin = new System.Windows.Forms.Label();
            this.comboBoxDia = new System.Windows.Forms.ComboBox();
            this.comboBoxHoraInicio = new System.Windows.Forms.ComboBox();
            this.comboBoxHoraFin = new System.Windows.Forms.ComboBox();
            this.buttonAgregar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelDia
            // 
            this.labelDia.AutoSize = true;
            this.labelDia.Location = new System.Drawing.Point(35, 51);
            this.labelDia.Name = "labelDia";
            this.labelDia.Size = new System.Drawing.Size(58, 32);
            this.labelDia.TabIndex = 0;
            this.labelDia.Text = "Dia";
            // 
            // labelHora
            // 
            this.labelHora.AutoSize = true;
            this.labelHora.Location = new System.Drawing.Point(458, 51);
            this.labelHora.Name = "labelHora";
            this.labelHora.Size = new System.Drawing.Size(150, 32);
            this.labelHora.TabIndex = 1;
            this.labelHora.Text = "Hora Inicio";
            // 
            // labelFin
            // 
            this.labelFin.AutoSize = true;
            this.labelFin.Location = new System.Drawing.Point(899, 51);
            this.labelFin.Name = "labelFin";
            this.labelFin.Size = new System.Drawing.Size(123, 32);
            this.labelFin.TabIndex = 2;
            this.labelFin.Text = "Hora Fin";
            // 
            // comboBoxDia
            // 
            this.comboBoxDia.FormattingEnabled = true;
            this.comboBoxDia.Location = new System.Drawing.Point(113, 48);
            this.comboBoxDia.Name = "comboBoxDia";
            this.comboBoxDia.Size = new System.Drawing.Size(256, 39);
            this.comboBoxDia.TabIndex = 3;
            // 
            // comboBoxHoraInicio
            // 
            this.comboBoxHoraInicio.FormattingEnabled = true;
            this.comboBoxHoraInicio.Location = new System.Drawing.Point(642, 51);
            this.comboBoxHoraInicio.Name = "comboBoxHoraInicio";
            this.comboBoxHoraInicio.Size = new System.Drawing.Size(157, 39);
            this.comboBoxHoraInicio.TabIndex = 4;
            // 
            // comboBoxHoraFin
            // 
            this.comboBoxHoraFin.FormattingEnabled = true;
            this.comboBoxHoraFin.Location = new System.Drawing.Point(1052, 51);
            this.comboBoxHoraFin.Name = "comboBoxHoraFin";
            this.comboBoxHoraFin.Size = new System.Drawing.Size(157, 39);
            this.comboBoxHoraFin.TabIndex = 5;
            // 
            // buttonAgregar
            // 
            this.buttonAgregar.Location = new System.Drawing.Point(1388, 51);
            this.buttonAgregar.Name = "buttonAgregar";
            this.buttonAgregar.Size = new System.Drawing.Size(181, 51);
            this.buttonAgregar.TabIndex = 6;
            this.buttonAgregar.Text = "Agregar";
            this.buttonAgregar.UseVisualStyleBackColor = true;
            this.buttonAgregar.Click += new System.EventHandler(this.buttonAgregar_Click);
            // 
            // ActividadNuevoHorario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1859, 755);
            this.Controls.Add(this.buttonAgregar);
            this.Controls.Add(this.comboBoxHoraFin);
            this.Controls.Add(this.comboBoxHoraInicio);
            this.Controls.Add(this.comboBoxDia);
            this.Controls.Add(this.labelFin);
            this.Controls.Add(this.labelHora);
            this.Controls.Add(this.labelDia);
            this.Name = "ActividadNuevoHorario";
            this.Text = "ActividadNuevoHorario";
            this.Load += new System.EventHandler(this.ActividadNuevoHorario_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelDia;
        private System.Windows.Forms.Label labelHora;
        private System.Windows.Forms.Label labelFin;
        private System.Windows.Forms.ComboBox comboBoxDia;
        private System.Windows.Forms.ComboBox comboBoxHoraInicio;
        private System.Windows.Forms.ComboBox comboBoxHoraFin;
        private System.Windows.Forms.Button buttonAgregar;
    }
}