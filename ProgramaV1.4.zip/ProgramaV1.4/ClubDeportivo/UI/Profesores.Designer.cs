﻿namespace UI
{
    partial class Profesores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAlta = new System.Windows.Forms.Button();
            this.buttonBaja = new System.Windows.Forms.Button();
            this.buttonModificar = new System.Windows.Forms.Button();
            this.buttonAsignar = new System.Windows.Forms.Button();
            this.buttonClases = new System.Windows.Forms.Button();
            this.buttonAtras = new System.Windows.Forms.Button();
            this.listBoxProfesores = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxDNI = new System.Windows.Forms.TextBox();
            this.buttonIr = new System.Windows.Forms.Button();
            this.buttonDesasignar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAlta
            // 
            this.buttonAlta.Location = new System.Drawing.Point(54, 43);
            this.buttonAlta.Name = "buttonAlta";
            this.buttonAlta.Size = new System.Drawing.Size(165, 23);
            this.buttonAlta.TabIndex = 0;
            this.buttonAlta.Text = "Dar de Alta";
            this.buttonAlta.UseVisualStyleBackColor = true;
            this.buttonAlta.Click += new System.EventHandler(this.buttonAlta_Click);
            // 
            // buttonBaja
            // 
            this.buttonBaja.Location = new System.Drawing.Point(55, 95);
            this.buttonBaja.Name = "buttonBaja";
            this.buttonBaja.Size = new System.Drawing.Size(164, 23);
            this.buttonBaja.TabIndex = 1;
            this.buttonBaja.Text = "Dar De Baja";
            this.buttonBaja.UseVisualStyleBackColor = true;
            this.buttonBaja.Click += new System.EventHandler(this.buttonBaja_Click);
            // 
            // buttonModificar
            // 
            this.buttonModificar.Location = new System.Drawing.Point(55, 150);
            this.buttonModificar.Name = "buttonModificar";
            this.buttonModificar.Size = new System.Drawing.Size(164, 23);
            this.buttonModificar.TabIndex = 2;
            this.buttonModificar.Text = "Modificar Datos";
            this.buttonModificar.UseVisualStyleBackColor = true;
            this.buttonModificar.Click += new System.EventHandler(this.buttonModificar_Click);
            // 
            // buttonAsignar
            // 
            this.buttonAsignar.Location = new System.Drawing.Point(55, 206);
            this.buttonAsignar.Name = "buttonAsignar";
            this.buttonAsignar.Size = new System.Drawing.Size(164, 23);
            this.buttonAsignar.TabIndex = 3;
            this.buttonAsignar.Text = "Asignar Actividad";
            this.buttonAsignar.UseVisualStyleBackColor = true;
            // 
            // buttonClases
            // 
            this.buttonClases.Location = new System.Drawing.Point(55, 323);
            this.buttonClases.Name = "buttonClases";
            this.buttonClases.Size = new System.Drawing.Size(163, 23);
            this.buttonClases.TabIndex = 4;
            this.buttonClases.Text = "Ver Clases y Horarios";
            this.buttonClases.UseVisualStyleBackColor = true;
            // 
            // buttonAtras
            // 
            this.buttonAtras.Location = new System.Drawing.Point(12, 376);
            this.buttonAtras.Name = "buttonAtras";
            this.buttonAtras.Size = new System.Drawing.Size(75, 23);
            this.buttonAtras.TabIndex = 5;
            this.buttonAtras.Text = "Atras";
            this.buttonAtras.UseVisualStyleBackColor = true;
            this.buttonAtras.Click += new System.EventHandler(this.buttonAtras_Click);
            // 
            // listBoxProfesores
            // 
            this.listBoxProfesores.FormattingEnabled = true;
            this.listBoxProfesores.Location = new System.Drawing.Point(369, 83);
            this.listBoxProfesores.Name = "listBoxProfesores";
            this.listBoxProfesores.Size = new System.Drawing.Size(219, 186);
            this.listBoxProfesores.TabIndex = 6;
            this.listBoxProfesores.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBoxProfesores_MouseDoubleClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(330, 311);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "DNI:";
            // 
            // textBoxDNI
            // 
            this.textBoxDNI.Location = new System.Drawing.Point(397, 308);
            this.textBoxDNI.Name = "textBoxDNI";
            this.textBoxDNI.Size = new System.Drawing.Size(100, 20);
            this.textBoxDNI.TabIndex = 9;
            // 
            // buttonIr
            // 
            this.buttonIr.Location = new System.Drawing.Point(544, 308);
            this.buttonIr.Name = "buttonIr";
            this.buttonIr.Size = new System.Drawing.Size(75, 23);
            this.buttonIr.TabIndex = 10;
            this.buttonIr.Text = "Ir";
            this.buttonIr.UseVisualStyleBackColor = true;
            // 
            // buttonDesasignar
            // 
            this.buttonDesasignar.Location = new System.Drawing.Point(56, 264);
            this.buttonDesasignar.Name = "buttonDesasignar";
            this.buttonDesasignar.Size = new System.Drawing.Size(163, 23);
            this.buttonDesasignar.TabIndex = 11;
            this.buttonDesasignar.Text = "Desasignar Actividad";
            this.buttonDesasignar.UseVisualStyleBackColor = true;
            // 
            // Profesores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 411);
            this.Controls.Add(this.buttonDesasignar);
            this.Controls.Add(this.buttonIr);
            this.Controls.Add(this.textBoxDNI);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBoxProfesores);
            this.Controls.Add(this.buttonAtras);
            this.Controls.Add(this.buttonClases);
            this.Controls.Add(this.buttonAsignar);
            this.Controls.Add(this.buttonModificar);
            this.Controls.Add(this.buttonBaja);
            this.Controls.Add(this.buttonAlta);
            this.Name = "Profesores";
            this.Text = "Profesores";
            this.Load += new System.EventHandler(this.Profesores_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAlta;
        private System.Windows.Forms.Button buttonBaja;
        private System.Windows.Forms.Button buttonModificar;
        private System.Windows.Forms.Button buttonAsignar;
        private System.Windows.Forms.Button buttonClases;
        private System.Windows.Forms.Button buttonAtras;
        private System.Windows.Forms.ListBox listBoxProfesores;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxDNI;
        private System.Windows.Forms.Button buttonIr;
        private System.Windows.Forms.Button buttonDesasignar;
    }
}