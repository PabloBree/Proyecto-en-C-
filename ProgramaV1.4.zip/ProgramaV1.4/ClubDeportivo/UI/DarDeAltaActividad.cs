﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class DarDeAltaActividad : Form
    {

        private ActividadDeportiva act;
        //private List<Dia> dias;
        private List<Dia> diasCopia;
        private ClubDeportivo cd;
        public DarDeAltaActividad(ClubDeportivo c)
        {
            InitializeComponent();
            cd = c;
           // dias = new List<Dia>();
            
        }

        public ActividadDeportiva darAct()
        {
                return act;

        }

        private void buttonVolverAct_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Seguro que desea salir?", "Se perderan los cambios no guardados !", MessageBoxButtons.YesNo);

            if (resultado == DialogResult.Yes)
            {
                this.Close();
            }
            else if (resultado == DialogResult.No)
            {

            }
         
        }

        private void buttonCrearActividad_Click(object sender, EventArgs e)
        {
            int id;
            string nombre;
            int cantMax;
            float costoClase;
            float costoMensual;

            id=int.Parse(textBoxCodAct.Text);
            nombre = textBoxNombreAct.Text;
            cantMax = int.Parse(textBoxCantMax.Text);
            costoClase = float.Parse(textBoxCostoClase.Text);
            costoMensual = float.Parse(textBoxCostoMensual.Text);

            //Falta verificar cuando los campos de la actividad no se llenan en su totalidad

            //ActividadCreada
                    act = new ActividadDeportiva(cantMax, costoMensual, costoClase, nombre, id);

            /*TEMA DIAS Y HORARIOS: HACER OTRO FORMULARIO CON LOS DIAS QUE TRAES DE LA CLASE Y PODER SELECCIONARLOS APARTE O
             * USAR UN COMBO PARA PODER TENER SELECCIONADOS LOS DIAS DE LA SEMANA PREVIAMENRE CARGADOS Y DARLE VALORES.
             * NO FALTA UN ATRIBUTO DE HORARIOS EN ESTA CLASE? CONSULTAR CON LOS CHICOS*/


        }

        private void DarDeAltaActividad_Load(object sender, EventArgs e)
        {

        }

        private void buttonNuevoHorario_Click(object sender, EventArgs e)
        {

            ActividadNuevoHorario anh = new ActividadNuevoHorario(cd,diasCopia);
            anh.ShowDialog();
        }
    }
}
