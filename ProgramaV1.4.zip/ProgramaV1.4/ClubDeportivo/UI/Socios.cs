﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class Socios : Form
    {
        private ClubDeportivo cd;
        public Socios(ClubDeportivo c)
        {
            InitializeComponent();
            cd = c;
            listBoxSocios.DataSource = null;
            listBoxSocios.DataSource = cd.darListaSocios();
            listBoxSocios.ClearSelected();
        }

        private void buttonAlta_Click(object sender, EventArgs e)
        {
            SocioClub soc=null;
            SocioActividades soC = null;
            DarDeAltaSocio aS = new DarDeAltaSocio(cd);
            aS.ShowDialog();

            soc = aS.darSocioClub();
            if (soc == null)
            {
                soC = aS.darSocioActividades();
                cd.AgregarSocioActLista(soC);
            }
            else
            {
                cd.AgregarSocioClubLista(soc);
            }




            listBoxSocios.DataSource = null;
            listBoxSocios.DataSource = cd.darListaSocios();
            listBoxSocios.ClearSelected();

        }

        private void Socios_Load(object sender, EventArgs e)
        {

        }

        private void buttonAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonBaja_Click(object sender, EventArgs e)
        {
            //falta eliminar de las sublistas correspondientes a CLUB y ACTIVIDADES
            //falta dar de baja de una actividad
            Socio soci = (Socio)listBoxSocios.SelectedItem;

            if (!cd.darListaSocios().Any())
                MessageBox.Show("No hay socios cargados");
            else
            {
                if (soci == null)
                    MessageBox.Show("No hay socio seleccionado");
                else
                {
                    //cd.EliminarSocioLista(soci);

                    listBoxSocios.DataSource = null;
                    listBoxSocios.DataSource = cd.darListaSocios();
                    listBoxSocios.ClearSelected();
                }
            }
        }

       

        private void buttonModificarDatos_Click(object sender, EventArgs e)
        {
            Socio ss = (Socio)listBoxSocios.SelectedItem;

            if (!cd.darListaSocios().Any())
                MessageBox.Show("No hay Socios cargados");
            else
            {
                if (ss == null)
                    MessageBox.Show("No hay socio seleccionado");
                else
                {
                    ModificarSocio ms = new ModificarSocio(ss);
                    ms.ShowDialog();

                    listBoxSocios.DataSource = null;
                    listBoxSocios.DataSource = cd.darListaSocios();
                    listBoxSocios.ClearSelected();
                }
            }
        }

        private void listBoxSocios_MouseDoubleClick_1(object sender, MouseEventArgs e)
        {
            Socio socc = (Socio)listBoxSocios.SelectedItem;
            DatosSocios ds = new DatosSocios(socc);
            ds.ShowDialog();
        }

        private void textBoxBuscar_TextChanged(object sender, EventArgs e)
        {
            var registrationsList = listBoxSocios.Items.Cast<String>().ToList();
            listBoxSocios.BeginUpdate();
            listBoxSocios.Items.Clear();
            foreach (string str in registrationsList)
            {
                if (str.Contains(textBoxBuscar.Text))
                {
                    listBoxSocios.Items.Add(str);
                }
            }
            listBoxSocios.EndUpdate();
        }
    }
}
