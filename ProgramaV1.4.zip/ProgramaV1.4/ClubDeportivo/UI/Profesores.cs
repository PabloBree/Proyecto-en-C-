﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class Profesores : Form
    {

        private ClubDeportivo cd;

        public Profesores(ClubDeportivo c)
        {
            InitializeComponent();
            cd = c;

            listBoxProfesores.DataSource = null;
            listBoxProfesores.DataSource = cd.darListaProfesores();
            listBoxProfesores.ClearSelected();
        }

        private void Profesores_Load(object sender, EventArgs e)
        {

        }

        private void buttonAlta_Click(object sender, EventArgs e)
        {
            Profesor prof = null;
            DarDeAltaProfesor ap = new DarDeAltaProfesor(cd);
            ap.ShowDialog();

            prof = ap.darprofesor();
            cd.AgregarProfesorLista(prof);

            listBoxProfesores.DataSource = null;
            listBoxProfesores.DataSource = cd.darListaProfesores();
            listBoxProfesores.ClearSelected();


        }

        private void buttonAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonBaja_Click(object sender, EventArgs e)
        {
             //Cuando estén creadas las actividades, hay que darlo de baja de esas también
             //Sino, si se da de baja el profesor, para que esto pase, antes tiene que estar desasignado
             //de las actividades (VALIDAR ESTO)
            Profesor prof = (Profesor)listBoxProfesores.SelectedItem;
           
            if (!cd.darListaProfesores().Any())
                MessageBox.Show("No hay profesores cargados");
            else
            {
                if (prof == null)
                    MessageBox.Show("No hay profesor seleccionado");
                else
                {
                    cd.EliminarProfesorLista(prof);

                    listBoxProfesores.DataSource = null;
                    listBoxProfesores.DataSource = cd.darListaProfesores();
                    listBoxProfesores.ClearSelected();
                }
            }
          
        }

        private void listBoxProfesores_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Profesor prof = (Profesor)listBoxProfesores.SelectedItem;
            DatosProfesores dp = new DatosProfesores(prof);
            dp.ShowDialog();
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {

            Profesor prof = (Profesor)listBoxProfesores.SelectedItem;
            
            if (!cd.darListaProfesores().Any())
                MessageBox.Show("No hay profesores cargados");
            else
            {
                if (prof == null)
                    MessageBox.Show("No hay profesor seleccionado");
                else
                {
                    ModificarProfesor mp = new ModificarProfesor(prof);
                    mp.ShowDialog();

                    listBoxProfesores.DataSource = null;
                    listBoxProfesores.DataSource = cd.darListaProfesores();
                    listBoxProfesores.ClearSelected();
                }
            }






        }
    }
}
