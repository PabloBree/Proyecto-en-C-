﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class LogIn : Form
    {
        
        public LogIn()
        {
            InitializeComponent();
      
            
        }

        private void buttonIngresar_Click(object sender, EventArgs e)
        {
            MenuPrincipal menu = new MenuPrincipal(this);
            menu.ShowDialog();
          

        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            

        }

       
    }
}
