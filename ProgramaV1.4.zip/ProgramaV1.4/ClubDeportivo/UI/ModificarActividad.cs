﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class ModificarActividad : Form
    {
        private ActividadDeportiva act;
        public ModificarActividad()
        {
            InitializeComponent();
        }

        private void buttonActualizarAct_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxNombreAct.Text) && (string.IsNullOrEmpty(textBoxCantMax.Text)) && (string.IsNullOrEmpty(textBoxCostoClase.Text)) && (string.IsNullOrEmpty(textBoxCostoMensual.Text)))
            {
                MessageBox.Show("No se cargo ningun dato. Por favor ingrese datos para actualizar");
                this.Close();
            }
                    
                else
                    act.DescripcionAct = textBoxNombreAct.Text;
                    act.CantMaxPart = int.Parse(textBoxCantMax.Text);
                    act.CostoClase = float.Parse(textBoxCostoClase.Text);
                    act.CostoMensual = float.Parse(textBoxCostoMensual.Text);

        }

        private void buttonVolModAct_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Seguro que desea salir?", "Se perderan los cambios no guardados !", MessageBoxButtons.YesNo);

            if (resultado == DialogResult.Yes)
            {
                this.Close();
            }
            else if (resultado == DialogResult.No)
            {

            }

        }
    }
}
