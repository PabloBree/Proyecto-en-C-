﻿namespace UI
{
    partial class DatosProfesores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxMProfesores = new System.Windows.Forms.PictureBox();
            this.labelDNI = new System.Windows.Forms.Label();
            this.labelMostrarDni = new System.Windows.Forms.Label();
            this.buttonCerrar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMProfesores)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxMProfesores
            // 
            this.pictureBoxMProfesores.Location = new System.Drawing.Point(89, 42);
            this.pictureBoxMProfesores.Name = "pictureBoxMProfesores";
            this.pictureBoxMProfesores.Size = new System.Drawing.Size(175, 155);
            this.pictureBoxMProfesores.TabIndex = 0;
            this.pictureBoxMProfesores.TabStop = false;
            // 
            // labelDNI
            // 
            this.labelDNI.AutoSize = true;
            this.labelDNI.Location = new System.Drawing.Point(106, 228);
            this.labelDNI.Name = "labelDNI";
            this.labelDNI.Size = new System.Drawing.Size(26, 13);
            this.labelDNI.TabIndex = 1;
            this.labelDNI.Text = "DNI";
            // 
            // labelMostrarDni
            // 
            this.labelMostrarDni.AutoSize = true;
            this.labelMostrarDni.Location = new System.Drawing.Point(195, 228);
            this.labelMostrarDni.Name = "labelMostrarDni";
            this.labelMostrarDni.Size = new System.Drawing.Size(0, 13);
            this.labelMostrarDni.TabIndex = 2;
            // 
            // buttonCerrar
            // 
            this.buttonCerrar.Location = new System.Drawing.Point(137, 322);
            this.buttonCerrar.Name = "buttonCerrar";
            this.buttonCerrar.Size = new System.Drawing.Size(75, 23);
            this.buttonCerrar.TabIndex = 3;
            this.buttonCerrar.Text = "Cerrar";
            this.buttonCerrar.UseVisualStyleBackColor = true;
            this.buttonCerrar.Click += new System.EventHandler(this.buttonCerrar_Click);
            // 
            // DatosProfesores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 357);
            this.Controls.Add(this.buttonCerrar);
            this.Controls.Add(this.labelMostrarDni);
            this.Controls.Add(this.labelDNI);
            this.Controls.Add(this.pictureBoxMProfesores);
            this.Name = "DatosProfesores";
            this.Text = "DatosProfesores";
            this.Load += new System.EventHandler(this.DatosProfesores_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMProfesores)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxMProfesores;
        private System.Windows.Forms.Label labelDNI;
        private System.Windows.Forms.Label labelMostrarDni;
        private System.Windows.Forms.Button buttonCerrar;
    }
}