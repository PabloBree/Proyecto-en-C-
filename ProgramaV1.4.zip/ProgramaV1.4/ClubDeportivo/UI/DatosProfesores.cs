﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class DatosProfesores : Form
    {
        private Profesor p;
        public DatosProfesores(Profesor prof)
        {
            InitializeComponent();
            p = prof;

            labelMostrarDni.Text =p.Dni.ToString() ;
            pictureBoxMProfesores.Image = p.ImagenPersona;


        }

        private void buttonCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DatosProfesores_Load(object sender, EventArgs e)
        {

        }

        
    }
}
