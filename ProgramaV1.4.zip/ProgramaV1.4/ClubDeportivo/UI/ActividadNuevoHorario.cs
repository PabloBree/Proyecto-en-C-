﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class ActividadNuevoHorario : Form
    {
        private ClubDeportivo cd;
        private List<Dia> dias; //copia
        private List<Dia> d; //original dada por la administradora

        public ActividadNuevoHorario(ClubDeportivo c, List<Dia> dd)
        {
            InitializeComponent();

            dias = dd;
            cd = c;
            d = cd.darDias();
            comboBoxHoraInicio.Items.Add("9");
            comboBoxHoraInicio.Items.Add("10");
            comboBoxHoraInicio.Items.Add("11");
            comboBoxHoraInicio.Items.Add("12");
            comboBoxHoraInicio.Items.Add("13");
            comboBoxHoraInicio.Items.Add("14");
            comboBoxHoraInicio.Items.Add("15");
            comboBoxHoraInicio.Items.Add("16");
            comboBoxHoraInicio.Items.Add("17");
            comboBoxHoraInicio.Items.Add("18");

            comboBoxHoraFin.Items.Add("10");
            comboBoxHoraFin.Items.Add("11");
            comboBoxHoraFin.Items.Add("12");
            comboBoxHoraFin.Items.Add("13");
            comboBoxHoraFin.Items.Add("14");
            comboBoxHoraFin.Items.Add("15");
            comboBoxHoraFin.Items.Add("16");
            comboBoxHoraFin.Items.Add("17");
            comboBoxHoraFin.Items.Add("18");
            comboBoxHoraFin.Items.Add("19");

            
            for (int i = 0; i < d.Count(); i++)
            {
                comboBoxDia.Items.Add(d[i].DescripcionDia);

            }
        }


        public List<Dia> devolverDias()
        {
            return dias;
        }

        private void ActividadNuevoHorario_Load(object sender, EventArgs e)
        {

        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            int  random = new Random().Next(0,100000);
            Horario hor;
            Dia de;
            int idDia=0;
            int hI = int.Parse(comboBoxHoraFin.SelectedText);
            int hF = int.Parse(comboBoxHoraFin.SelectedText);
            String dia = comboBoxDia.SelectedItem.ToString();

            for (int i = 0; i < d.Count(); i++)
            {
                if (dia == d[i].DescripcionDia)
                {
                    idDia = d[i].IdDia;
                }
                  
               
            }

            if (idDia != 0)
            {
                de = new Dia(dia, idDia);

                hor = new Horario(hI, hF, random, de);

                de.agregarHorario(hor);
                dias.Add(de);

            }
            else
                MessageBox.Show("Error");
                



        }
    }
}
