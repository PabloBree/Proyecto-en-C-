﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class MenuPrincipal : Form
    {
        private ClubDeportivo c;
        public MenuPrincipal(LogIn l)
        {
            InitializeComponent();
            l.Hide();
            c = new ClubDeportivo();
            
        }

        private void MenuPrincipal_Load(object sender, EventArgs e)
        {
          
        }

        private void buttonSocios_Click(object sender, EventArgs e)
        {
            Socios s = new Socios(c);
            s.ShowDialog();
        }

        private void buttonProfesores_Click(object sender, EventArgs e)
        {
            Profesores p = new Profesores(c);
            p.ShowDialog();
          
        }

        private void buttonActividades_Click(object sender, EventArgs e)
        {
            Actividades a = new Actividades(c);
            a.ShowDialog();
        }
    }
}
