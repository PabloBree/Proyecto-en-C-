﻿namespace UI
{
    partial class ModificarSocio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxDireccion = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxTelefono = new System.Windows.Forms.TextBox();
            this.buttonDireccion = new System.Windows.Forms.Button();
            this.buttonEmail = new System.Windows.Forms.Button();
            this.buttonTelefono = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.webCamSocio = new WebCAM.WebCam();
            this.pictureBoxSocio = new System.Windows.Forms.PictureBox();
            this.buttonIniciar = new System.Windows.Forms.Button();
            this.buttonCapturar = new System.Windows.Forms.Button();
            this.buttonCamara = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSocio)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(624, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(309, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "¿Qué desea Modificar?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(291, 177);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Dirección";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(291, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(291, 365);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 32);
            this.label4.TabIndex = 3;
            this.label4.Text = "Teléfono";
            // 
            // textBoxDireccion
            // 
            this.textBoxDireccion.Location = new System.Drawing.Point(630, 166);
            this.textBoxDireccion.Name = "textBoxDireccion";
            this.textBoxDireccion.Size = new System.Drawing.Size(303, 38);
            this.textBoxDireccion.TabIndex = 4;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(630, 265);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(303, 38);
            this.textBoxEmail.TabIndex = 5;
            // 
            // textBoxTelefono
            // 
            this.textBoxTelefono.Location = new System.Drawing.Point(630, 362);
            this.textBoxTelefono.Name = "textBoxTelefono";
            this.textBoxTelefono.Size = new System.Drawing.Size(303, 38);
            this.textBoxTelefono.TabIndex = 6;
            // 
            // buttonDireccion
            // 
            this.buttonDireccion.Location = new System.Drawing.Point(1113, 151);
            this.buttonDireccion.Name = "buttonDireccion";
            this.buttonDireccion.Size = new System.Drawing.Size(198, 53);
            this.buttonDireccion.TabIndex = 7;
            this.buttonDireccion.Text = "Actualizar";
            this.buttonDireccion.UseVisualStyleBackColor = true;
            this.buttonDireccion.Click += new System.EventHandler(this.buttonDireccion_Click);
            // 
            // buttonEmail
            // 
            this.buttonEmail.Location = new System.Drawing.Point(1113, 255);
            this.buttonEmail.Name = "buttonEmail";
            this.buttonEmail.Size = new System.Drawing.Size(198, 56);
            this.buttonEmail.TabIndex = 8;
            this.buttonEmail.Text = "Actualizar";
            this.buttonEmail.UseVisualStyleBackColor = true;
            this.buttonEmail.Click += new System.EventHandler(this.buttonEmail_Click);
            // 
            // buttonTelefono
            // 
            this.buttonTelefono.Location = new System.Drawing.Point(1113, 347);
            this.buttonTelefono.Name = "buttonTelefono";
            this.buttonTelefono.Size = new System.Drawing.Size(198, 50);
            this.buttonTelefono.TabIndex = 9;
            this.buttonTelefono.Text = "Actualizar";
            this.buttonTelefono.UseVisualStyleBackColor = true;
            this.buttonTelefono.Click += new System.EventHandler(this.buttonTelefono_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(624, 457);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(323, 32);
            this.label5.TabIndex = 10;
            this.label5.Text = "¿Quiere tomar otra foto?";
            // 
            // webCamSocio
            // 
            this.webCamSocio.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.webCamSocio.Imagen = null;
            this.webCamSocio.Location = new System.Drawing.Point(366, 522);
            this.webCamSocio.MilisegundosCaptura = 100;
            this.webCamSocio.Name = "webCamSocio";
            this.webCamSocio.Size = new System.Drawing.Size(460, 392);
            this.webCamSocio.TabIndex = 11;
            // 
            // pictureBoxSocio
            // 
            this.pictureBoxSocio.Location = new System.Drawing.Point(948, 522);
            this.pictureBoxSocio.Name = "pictureBoxSocio";
            this.pictureBoxSocio.Size = new System.Drawing.Size(460, 418);
            this.pictureBoxSocio.TabIndex = 12;
            this.pictureBoxSocio.TabStop = false;
            // 
            // buttonIniciar
            // 
            this.buttonIniciar.Location = new System.Drawing.Point(464, 983);
            this.buttonIniciar.Name = "buttonIniciar";
            this.buttonIniciar.Size = new System.Drawing.Size(180, 56);
            this.buttonIniciar.TabIndex = 13;
            this.buttonIniciar.Text = "Iniciar";
            this.buttonIniciar.UseVisualStyleBackColor = true;
            this.buttonIniciar.Click += new System.EventHandler(this.buttonIniciar_Click);
            // 
            // buttonCapturar
            // 
            this.buttonCapturar.Location = new System.Drawing.Point(1047, 983);
            this.buttonCapturar.Name = "buttonCapturar";
            this.buttonCapturar.Size = new System.Drawing.Size(179, 56);
            this.buttonCapturar.TabIndex = 14;
            this.buttonCapturar.Text = "Capturar";
            this.buttonCapturar.UseVisualStyleBackColor = true;
            this.buttonCapturar.Click += new System.EventHandler(this.buttonCapturar_Click);
            // 
            // buttonCamara
            // 
            this.buttonCamara.Location = new System.Drawing.Point(1474, 718);
            this.buttonCamara.Name = "buttonCamara";
            this.buttonCamara.Size = new System.Drawing.Size(185, 56);
            this.buttonCamara.TabIndex = 15;
            this.buttonCamara.Text = "Actualizar";
            this.buttonCamara.UseVisualStyleBackColor = true;
            this.buttonCamara.Click += new System.EventHandler(this.buttonCamara_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(35, 1095);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(229, 68);
            this.button1.TabIndex = 16;
            this.button1.Text = "Atras";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ModificarSocio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1732, 1175);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonCamara);
            this.Controls.Add(this.buttonCapturar);
            this.Controls.Add(this.buttonIniciar);
            this.Controls.Add(this.pictureBoxSocio);
            this.Controls.Add(this.webCamSocio);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.buttonTelefono);
            this.Controls.Add(this.buttonEmail);
            this.Controls.Add(this.buttonDireccion);
            this.Controls.Add(this.textBoxTelefono);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxDireccion);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ModificarSocio";
            this.Text = "ModificarSocio";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSocio)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxDireccion;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxTelefono;
        private System.Windows.Forms.Button buttonDireccion;
        private System.Windows.Forms.Button buttonEmail;
        private System.Windows.Forms.Button buttonTelefono;
        private System.Windows.Forms.Label label5;
        private WebCAM.WebCam webCamSocio;
        private System.Windows.Forms.PictureBox pictureBoxSocio;
        private System.Windows.Forms.Button buttonIniciar;
        private System.Windows.Forms.Button buttonCapturar;
        private System.Windows.Forms.Button buttonCamara;
        private System.Windows.Forms.Button button1;
    }
}