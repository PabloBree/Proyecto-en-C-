﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class DarDeAltaProfesor : Form
    {
        private Image fotoProf;
        private ClubDeportivo cd;
        private Profesor prof;

        public DarDeAltaProfesor(ClubDeportivo c)
        {
            InitializeComponent();
            cd = c;
        }

        private void DarDeAltaProfesor_Load(object sender, EventArgs e)
        {

        }

        private void buttonIniciar_Click(object sender, EventArgs e)
        {
            webCamProfesor.Start();
            webCamProfesor.Start();
            webCamProfesor.Start();
        }

        private void buttonGenerar_Click(object sender, EventArgs e)
        {
            String a, n, d, email;
            int dni, telefono,numE;
            a = textBoxApellido.Text;
            n = textBoxNombre.Text;
            d = textBoxDireccion.Text;
            email = textBoxEMAIL.Text;
            dni = int.Parse(textBoxDNI.Text);
            telefono = int.Parse(textBoxTelefono.Text);
            numE = cd.DarNumeroIdProfesor();
            prof = new Profesor(a, n, d, dni, email, telefono, fotoProf, numE);

            if (prof != null)
                MessageBox.Show("Carga exitosa");
            else
                MessageBox.Show("Error en la carga");

        }

        private void buttonCapturar_Click(object sender, EventArgs e)
        {
            pictureBoxProfesor.Image = webCamProfesor.Imagen;
            fotoProf = webCamProfesor.Imagen;
        }

        private void buttonAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public Profesor darprofesor()
        {
            return prof;
        }


    }




}
