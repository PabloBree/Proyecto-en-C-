﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class DatosSocios : Form
    {
        private Socio soc;
        public DatosSocios(Socio s)
        {
            InitializeComponent();
            soc = s;
            labelMostrarDNI.Text = soc.Dni.ToString();
            pictureBoxMSocio.Image = soc.ImagenPersona;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
