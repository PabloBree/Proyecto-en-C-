﻿namespace UI
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSocios = new System.Windows.Forms.Button();
            this.buttonProfesores = new System.Windows.Forms.Button();
            this.buttonPagos = new System.Windows.Forms.Button();
            this.buttonActividades = new System.Windows.Forms.Button();
            this.buttonSalir = new System.Windows.Forms.Button();
            this.buttonAdministracion = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonSocios
            // 
            this.buttonSocios.Location = new System.Drawing.Point(87, 84);
            this.buttonSocios.Margin = new System.Windows.Forms.Padding(1);
            this.buttonSocios.Name = "buttonSocios";
            this.buttonSocios.Size = new System.Drawing.Size(74, 38);
            this.buttonSocios.TabIndex = 0;
            this.buttonSocios.Text = "Socios";
            this.buttonSocios.UseVisualStyleBackColor = true;
            this.buttonSocios.Click += new System.EventHandler(this.buttonSocios_Click);
            // 
            // buttonProfesores
            // 
            this.buttonProfesores.Location = new System.Drawing.Point(185, 84);
            this.buttonProfesores.Margin = new System.Windows.Forms.Padding(1);
            this.buttonProfesores.Name = "buttonProfesores";
            this.buttonProfesores.Size = new System.Drawing.Size(74, 38);
            this.buttonProfesores.TabIndex = 1;
            this.buttonProfesores.Text = "Profesores";
            this.buttonProfesores.UseVisualStyleBackColor = true;
            this.buttonProfesores.Click += new System.EventHandler(this.buttonProfesores_Click);
            // 
            // buttonPagos
            // 
            this.buttonPagos.Location = new System.Drawing.Point(281, 84);
            this.buttonPagos.Margin = new System.Windows.Forms.Padding(1);
            this.buttonPagos.Name = "buttonPagos";
            this.buttonPagos.Size = new System.Drawing.Size(74, 38);
            this.buttonPagos.TabIndex = 2;
            this.buttonPagos.Text = "Pagos";
            this.buttonPagos.UseVisualStyleBackColor = true;
            // 
            // buttonActividades
            // 
            this.buttonActividades.Location = new System.Drawing.Point(376, 84);
            this.buttonActividades.Margin = new System.Windows.Forms.Padding(1);
            this.buttonActividades.Name = "buttonActividades";
            this.buttonActividades.Size = new System.Drawing.Size(74, 38);
            this.buttonActividades.TabIndex = 3;
            this.buttonActividades.Text = "Actividades";
            this.buttonActividades.UseVisualStyleBackColor = true;
            this.buttonActividades.Click += new System.EventHandler(this.buttonActividades_Click);
            // 
            // buttonSalir
            // 
            this.buttonSalir.Location = new System.Drawing.Point(27, 217);
            this.buttonSalir.Margin = new System.Windows.Forms.Padding(1);
            this.buttonSalir.Name = "buttonSalir";
            this.buttonSalir.Size = new System.Drawing.Size(76, 26);
            this.buttonSalir.TabIndex = 4;
            this.buttonSalir.Text = "Salir";
            this.buttonSalir.UseVisualStyleBackColor = true;
            // 
            // buttonAdministracion
            // 
            this.buttonAdministracion.Location = new System.Drawing.Point(403, 214);
            this.buttonAdministracion.Margin = new System.Windows.Forms.Padding(1);
            this.buttonAdministracion.Name = "buttonAdministracion";
            this.buttonAdministracion.Size = new System.Drawing.Size(121, 29);
            this.buttonAdministracion.TabIndex = 5;
            this.buttonAdministracion.Text = "Administracion";
            this.buttonAdministracion.UseVisualStyleBackColor = true;
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 265);
            this.Controls.Add(this.buttonAdministracion);
            this.Controls.Add(this.buttonSalir);
            this.Controls.Add(this.buttonActividades);
            this.Controls.Add(this.buttonPagos);
            this.Controls.Add(this.buttonProfesores);
            this.Controls.Add(this.buttonSocios);
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "MenuPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MenuPrincipal";
            this.Load += new System.EventHandler(this.MenuPrincipal_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSocios;
        private System.Windows.Forms.Button buttonProfesores;
        private System.Windows.Forms.Button buttonPagos;
        private System.Windows.Forms.Button buttonActividades;
        private System.Windows.Forms.Button buttonSalir;
        private System.Windows.Forms.Button buttonAdministracion;
    }
}