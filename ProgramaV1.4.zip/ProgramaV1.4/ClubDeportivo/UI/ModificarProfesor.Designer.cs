﻿namespace UI
{
    partial class ModificarProfesor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.labelDireccion = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelTelefono = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.webCamModificar = new WebCAM.WebCam();
            this.pictureBoxModificar = new System.Windows.Forms.PictureBox();
            this.buttonDir = new System.Windows.Forms.Button();
            this.buttonEmail = new System.Windows.Forms.Button();
            this.buttonTelefono = new System.Windows.Forms.Button();
            this.buttonIniciar = new System.Windows.Forms.Button();
            this.buttonCapturar = new System.Windows.Forms.Button();
            this.buttonActualizar = new System.Windows.Forms.Button();
            this.buttonAtras = new System.Windows.Forms.Button();
            this.textBoxDireccion = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxTelefono = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxModificar)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(225, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "¿Qué desea modificar?";
            // 
            // labelDireccion
            // 
            this.labelDireccion.AutoSize = true;
            this.labelDireccion.Location = new System.Drawing.Point(92, 72);
            this.labelDireccion.Name = "labelDireccion";
            this.labelDireccion.Size = new System.Drawing.Size(52, 13);
            this.labelDireccion.TabIndex = 1;
            this.labelDireccion.Text = "Dirección";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(92, 120);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(32, 13);
            this.labelEmail.TabIndex = 2;
            this.labelEmail.Text = "Email";
            // 
            // labelTelefono
            // 
            this.labelTelefono.AutoSize = true;
            this.labelTelefono.Location = new System.Drawing.Point(92, 166);
            this.labelTelefono.Name = "labelTelefono";
            this.labelTelefono.Size = new System.Drawing.Size(49, 13);
            this.labelTelefono.TabIndex = 3;
            this.labelTelefono.Text = "Teléfono";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(220, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "¿Quiere tomar otra foto?";
            // 
            // webCamModificar
            // 
            this.webCamModificar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.webCamModificar.Imagen = null;
            this.webCamModificar.Location = new System.Drawing.Point(107, 266);
            this.webCamModificar.MilisegundosCaptura = 100;
            this.webCamModificar.Name = "webCamModificar";
            this.webCamModificar.Size = new System.Drawing.Size(150, 146);
            this.webCamModificar.TabIndex = 5;
            // 
            // pictureBoxModificar
            // 
            this.pictureBoxModificar.Location = new System.Drawing.Point(305, 266);
            this.pictureBoxModificar.Name = "pictureBoxModificar";
            this.pictureBoxModificar.Size = new System.Drawing.Size(150, 146);
            this.pictureBoxModificar.TabIndex = 6;
            this.pictureBoxModificar.TabStop = false;
            // 
            // buttonDir
            // 
            this.buttonDir.Location = new System.Drawing.Point(408, 67);
            this.buttonDir.Name = "buttonDir";
            this.buttonDir.Size = new System.Drawing.Size(75, 23);
            this.buttonDir.TabIndex = 7;
            this.buttonDir.Text = "Actualizar";
            this.buttonDir.UseVisualStyleBackColor = true;
            this.buttonDir.Click += new System.EventHandler(this.buttonDir_Click);
            // 
            // buttonEmail
            // 
            this.buttonEmail.Location = new System.Drawing.Point(408, 120);
            this.buttonEmail.Name = "buttonEmail";
            this.buttonEmail.Size = new System.Drawing.Size(75, 23);
            this.buttonEmail.TabIndex = 8;
            this.buttonEmail.Text = "Actualizar";
            this.buttonEmail.UseVisualStyleBackColor = true;
            this.buttonEmail.Click += new System.EventHandler(this.buttonEmail_Click);
            // 
            // buttonTelefono
            // 
            this.buttonTelefono.Location = new System.Drawing.Point(408, 166);
            this.buttonTelefono.Name = "buttonTelefono";
            this.buttonTelefono.Size = new System.Drawing.Size(75, 23);
            this.buttonTelefono.TabIndex = 9;
            this.buttonTelefono.Text = "Actualizar";
            this.buttonTelefono.UseVisualStyleBackColor = true;
            this.buttonTelefono.Click += new System.EventHandler(this.buttonTelefono_Click);
            // 
            // buttonIniciar
            // 
            this.buttonIniciar.Location = new System.Drawing.Point(137, 427);
            this.buttonIniciar.Name = "buttonIniciar";
            this.buttonIniciar.Size = new System.Drawing.Size(75, 23);
            this.buttonIniciar.TabIndex = 10;
            this.buttonIniciar.Text = "Iniciar";
            this.buttonIniciar.UseVisualStyleBackColor = true;
            this.buttonIniciar.Click += new System.EventHandler(this.buttonIniciar_Click);
            // 
            // buttonCapturar
            // 
            this.buttonCapturar.Location = new System.Drawing.Point(344, 427);
            this.buttonCapturar.Name = "buttonCapturar";
            this.buttonCapturar.Size = new System.Drawing.Size(75, 23);
            this.buttonCapturar.TabIndex = 11;
            this.buttonCapturar.Text = "Capturar";
            this.buttonCapturar.UseVisualStyleBackColor = true;
            this.buttonCapturar.Click += new System.EventHandler(this.buttonCapturar_Click);
            // 
            // buttonActualizar
            // 
            this.buttonActualizar.Location = new System.Drawing.Point(490, 342);
            this.buttonActualizar.Name = "buttonActualizar";
            this.buttonActualizar.Size = new System.Drawing.Size(75, 23);
            this.buttonActualizar.TabIndex = 12;
            this.buttonActualizar.Text = "Actualizar";
            this.buttonActualizar.UseVisualStyleBackColor = true;
            this.buttonActualizar.Click += new System.EventHandler(this.buttonActualizar_Click);
            // 
            // buttonAtras
            // 
            this.buttonAtras.Location = new System.Drawing.Point(12, 460);
            this.buttonAtras.Name = "buttonAtras";
            this.buttonAtras.Size = new System.Drawing.Size(75, 23);
            this.buttonAtras.TabIndex = 13;
            this.buttonAtras.Text = "Atras";
            this.buttonAtras.UseVisualStyleBackColor = true;
            this.buttonAtras.Click += new System.EventHandler(this.buttonAtras_Click);
            // 
            // textBoxDireccion
            // 
            this.textBoxDireccion.Location = new System.Drawing.Point(207, 70);
            this.textBoxDireccion.Name = "textBoxDireccion";
            this.textBoxDireccion.Size = new System.Drawing.Size(138, 20);
            this.textBoxDireccion.TabIndex = 14;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(207, 122);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(138, 20);
            this.textBoxEmail.TabIndex = 15;
            // 
            // textBoxTelefono
            // 
            this.textBoxTelefono.Location = new System.Drawing.Point(207, 169);
            this.textBoxTelefono.Name = "textBoxTelefono";
            this.textBoxTelefono.Size = new System.Drawing.Size(138, 20);
            this.textBoxTelefono.TabIndex = 16;
            // 
            // ModificarProfesor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(613, 495);
            this.Controls.Add(this.textBoxTelefono);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxDireccion);
            this.Controls.Add(this.buttonAtras);
            this.Controls.Add(this.buttonActualizar);
            this.Controls.Add(this.buttonCapturar);
            this.Controls.Add(this.buttonIniciar);
            this.Controls.Add(this.buttonTelefono);
            this.Controls.Add(this.buttonEmail);
            this.Controls.Add(this.buttonDir);
            this.Controls.Add(this.pictureBoxModificar);
            this.Controls.Add(this.webCamModificar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelTelefono);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelDireccion);
            this.Controls.Add(this.label1);
            this.Name = "ModificarProfesor";
            this.Text = "ModificarProfesor";
            this.Load += new System.EventHandler(this.ModificarProfesor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxModificar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelDireccion;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelTelefono;
        private System.Windows.Forms.Label label2;
        private WebCAM.WebCam webCamModificar;
        private System.Windows.Forms.PictureBox pictureBoxModificar;
        private System.Windows.Forms.Button buttonDir;
        private System.Windows.Forms.Button buttonEmail;
        private System.Windows.Forms.Button buttonTelefono;
        private System.Windows.Forms.Button buttonIniciar;
        private System.Windows.Forms.Button buttonCapturar;
        private System.Windows.Forms.Button buttonActualizar;
        private System.Windows.Forms.Button buttonAtras;
        private System.Windows.Forms.TextBox textBoxDireccion;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxTelefono;
    }
}