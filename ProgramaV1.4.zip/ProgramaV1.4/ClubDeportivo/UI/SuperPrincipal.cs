﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class SuperPrincipal : Form
    {
        public SuperPrincipal()
        {
            InitializeComponent();
        }

        private void buttonIniciar_Click(object sender, EventArgs e)
        {
            LogIn l = new LogIn();
            l.ShowDialog();
           
           
        }

        private void SuperPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
