﻿namespace UI
{
    partial class Socios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAlta = new System.Windows.Forms.Button();
            this.buttonBaja = new System.Windows.Forms.Button();
            this.buttonModificarDatos = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonInscribirAct = new System.Windows.Forms.Button();
            this.buttonBuscar = new System.Windows.Forms.Button();
            this.textBoxBuscar = new System.Windows.Forms.TextBox();
            this.listBoxSocios = new System.Windows.Forms.ListBox();
            this.labelDNI = new System.Windows.Forms.Label();
            this.buttonAtras = new System.Windows.Forms.Button();
            this.buttonHorarios = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAlta
            // 
            this.buttonAlta.Location = new System.Drawing.Point(56, 57);
            this.buttonAlta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonAlta.Name = "buttonAlta";
            this.buttonAlta.Size = new System.Drawing.Size(501, 50);
            this.buttonAlta.TabIndex = 0;
            this.buttonAlta.Text = "Dar de Alta";
            this.buttonAlta.UseVisualStyleBackColor = true;
            this.buttonAlta.Click += new System.EventHandler(this.buttonAlta_Click);
            // 
            // buttonBaja
            // 
            this.buttonBaja.Location = new System.Drawing.Point(56, 191);
            this.buttonBaja.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonBaja.Name = "buttonBaja";
            this.buttonBaja.Size = new System.Drawing.Size(501, 45);
            this.buttonBaja.TabIndex = 1;
            this.buttonBaja.Text = "Dar de Baja";
            this.buttonBaja.UseVisualStyleBackColor = true;
            this.buttonBaja.Click += new System.EventHandler(this.buttonBaja_Click);
            // 
            // buttonModificarDatos
            // 
            this.buttonModificarDatos.Location = new System.Drawing.Point(56, 336);
            this.buttonModificarDatos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonModificarDatos.Name = "buttonModificarDatos";
            this.buttonModificarDatos.Size = new System.Drawing.Size(501, 50);
            this.buttonModificarDatos.TabIndex = 2;
            this.buttonModificarDatos.Text = "Modificar Datos";
            this.buttonModificarDatos.UseVisualStyleBackColor = true;
            this.buttonModificarDatos.Click += new System.EventHandler(this.buttonModificarDatos_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(171, 434);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 7);
            this.button1.TabIndex = 3;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // buttonInscribirAct
            // 
            this.buttonInscribirAct.Location = new System.Drawing.Point(56, 484);
            this.buttonInscribirAct.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonInscribirAct.Name = "buttonInscribirAct";
            this.buttonInscribirAct.Size = new System.Drawing.Size(501, 48);
            this.buttonInscribirAct.TabIndex = 4;
            this.buttonInscribirAct.Text = "Inscripciones a Actividades";
            this.buttonInscribirAct.UseVisualStyleBackColor = true;
            // 
            // buttonBuscar
            // 
            this.buttonBuscar.Location = new System.Drawing.Point(1439, 608);
            this.buttonBuscar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonBuscar.Name = "buttonBuscar";
            this.buttonBuscar.Size = new System.Drawing.Size(93, 50);
            this.buttonBuscar.TabIndex = 5;
            this.buttonBuscar.Text = "IR";
            this.buttonBuscar.UseVisualStyleBackColor = true;
            // 
            // textBoxBuscar
            // 
            this.textBoxBuscar.Location = new System.Drawing.Point(1000, 620);
            this.textBoxBuscar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxBuscar.Name = "textBoxBuscar";
            this.textBoxBuscar.Size = new System.Drawing.Size(308, 38);
            this.textBoxBuscar.TabIndex = 6;
            this.textBoxBuscar.TextChanged += new System.EventHandler(this.textBoxBuscar_TextChanged);
            // 
            // listBoxSocios
            // 
            this.listBoxSocios.FormattingEnabled = true;
            this.listBoxSocios.ItemHeight = 31;
            this.listBoxSocios.Location = new System.Drawing.Point(901, 57);
            this.listBoxSocios.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBoxSocios.Name = "listBoxSocios";
            this.listBoxSocios.Size = new System.Drawing.Size(620, 469);
            this.listBoxSocios.TabIndex = 7;
            this.listBoxSocios.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBoxSocios_MouseDoubleClick_1);
            // 
            // labelDNI
            // 
            this.labelDNI.AutoSize = true;
            this.labelDNI.Location = new System.Drawing.Point(773, 620);
            this.labelDNI.Name = "labelDNI";
            this.labelDNI.Size = new System.Drawing.Size(70, 32);
            this.labelDNI.TabIndex = 8;
            this.labelDNI.Text = "DNI:";
            // 
            // buttonAtras
            // 
            this.buttonAtras.Location = new System.Drawing.Point(56, 756);
            this.buttonAtras.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonAtras.Name = "buttonAtras";
            this.buttonAtras.Size = new System.Drawing.Size(157, 69);
            this.buttonAtras.TabIndex = 9;
            this.buttonAtras.Text = "Atras";
            this.buttonAtras.UseVisualStyleBackColor = true;
            this.buttonAtras.Click += new System.EventHandler(this.buttonAtras_Click);
            // 
            // buttonHorarios
            // 
            this.buttonHorarios.Location = new System.Drawing.Point(56, 613);
            this.buttonHorarios.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonHorarios.Name = "buttonHorarios";
            this.buttonHorarios.Size = new System.Drawing.Size(501, 55);
            this.buttonHorarios.TabIndex = 10;
            this.buttonHorarios.Text = "Ver Clases y Horarios";
            this.buttonHorarios.UseVisualStyleBackColor = true;
            // 
            // Socios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1915, 849);
            this.Controls.Add(this.buttonHorarios);
            this.Controls.Add(this.buttonAtras);
            this.Controls.Add(this.labelDNI);
            this.Controls.Add(this.listBoxSocios);
            this.Controls.Add(this.textBoxBuscar);
            this.Controls.Add(this.buttonBuscar);
            this.Controls.Add(this.buttonInscribirAct);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonModificarDatos);
            this.Controls.Add(this.buttonBaja);
            this.Controls.Add(this.buttonAlta);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Socios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Socios";
            this.Load += new System.EventHandler(this.Socios_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAlta;
        private System.Windows.Forms.Button buttonBaja;
        private System.Windows.Forms.Button buttonModificarDatos;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonInscribirAct;
        private System.Windows.Forms.Button buttonBuscar;
        private System.Windows.Forms.TextBox textBoxBuscar;
        private System.Windows.Forms.ListBox listBoxSocios;
        private System.Windows.Forms.Label labelDNI;
        private System.Windows.Forms.Button buttonAtras;
        private System.Windows.Forms.Button buttonHorarios;
    }
}