﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class ModificarProfesor : Form
    {
        private Profesor p;
        public ModificarProfesor(Profesor prof)
        {
            InitializeComponent();
            p = prof;
        }

        private void ModificarProfesor_Load(object sender, EventArgs e)
        {

        }

        private void buttonDir_Click(object sender, EventArgs e)
        {
            p.Direccion = textBoxDireccion.Text;
        }

        private void buttonEmail_Click(object sender, EventArgs e)
        {
            p.Email = textBoxEmail.Text;
        }

        private void buttonTelefono_Click(object sender, EventArgs e)
        {
            p.Telefono = int.Parse(textBoxTelefono.Text);
        }

        private void buttonIniciar_Click(object sender, EventArgs e)
        {
            webCamModificar.Start();
            webCamModificar.Start();
            webCamModificar.Start();
        }

        private void buttonCapturar_Click(object sender, EventArgs e)
        {
            pictureBoxModificar.Image = webCamModificar.Imagen;
        }

        private void buttonActualizar_Click(object sender, EventArgs e)
        {
            p.ImagenPersona = webCamModificar.Imagen;
        }

        private void buttonAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
