﻿namespace UI
{
    partial class DarDeAltaActividad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.labelsigno = new System.Windows.Forms.Label();
            this.textBoxCostoMensual = new System.Windows.Forms.TextBox();
            this.textBoxCostoClase = new System.Windows.Forms.TextBox();
            this.labelCostoMensual = new System.Windows.Forms.Label();
            this.labelCostoClase = new System.Windows.Forms.Label();
            this.textBoxCantMax = new System.Windows.Forms.TextBox();
            this.labelCantMax = new System.Windows.Forms.Label();
            this.textBoxNombreAct = new System.Windows.Forms.TextBox();
            this.textBoxCodAct = new System.Windows.Forms.TextBox();
            this.labelCodigoAct = new System.Windows.Forms.Label();
            this.labelNombreAct = new System.Windows.Forms.Label();
            this.buttonCrearActividad = new System.Windows.Forms.Button();
            this.buttonVolverAct = new System.Windows.Forms.Button();
            this.listBoxHorarios = new System.Windows.Forms.ListBox();
            this.buttonNuevoHorario = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(512, 630);
            this.label1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 32);
            this.label1.TabIndex = 24;
            this.label1.Text = "$";
            // 
            // labelsigno
            // 
            this.labelsigno.AutoSize = true;
            this.labelsigno.Location = new System.Drawing.Point(512, 511);
            this.labelsigno.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.labelsigno.Name = "labelsigno";
            this.labelsigno.Size = new System.Drawing.Size(31, 32);
            this.labelsigno.TabIndex = 23;
            this.labelsigno.Text = "$";
            // 
            // textBoxCostoMensual
            // 
            this.textBoxCostoMensual.Location = new System.Drawing.Point(563, 623);
            this.textBoxCostoMensual.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxCostoMensual.Name = "textBoxCostoMensual";
            this.textBoxCostoMensual.Size = new System.Drawing.Size(172, 38);
            this.textBoxCostoMensual.TabIndex = 22;
            // 
            // textBoxCostoClase
            // 
            this.textBoxCostoClase.Location = new System.Drawing.Point(563, 504);
            this.textBoxCostoClase.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxCostoClase.Name = "textBoxCostoClase";
            this.textBoxCostoClase.Size = new System.Drawing.Size(172, 38);
            this.textBoxCostoClase.TabIndex = 21;
            // 
            // labelCostoMensual
            // 
            this.labelCostoMensual.AutoSize = true;
            this.labelCostoMensual.Location = new System.Drawing.Point(64, 640);
            this.labelCostoMensual.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.labelCostoMensual.Name = "labelCostoMensual";
            this.labelCostoMensual.Size = new System.Drawing.Size(415, 32);
            this.labelCostoMensual.TabIndex = 20;
            this.labelCostoMensual.Text = "Costo Mensual (de la Actividad)";
            // 
            // labelCostoClase
            // 
            this.labelCostoClase.AutoSize = true;
            this.labelCostoClase.Location = new System.Drawing.Point(64, 520);
            this.labelCostoClase.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.labelCostoClase.Name = "labelCostoClase";
            this.labelCostoClase.Size = new System.Drawing.Size(219, 32);
            this.labelCostoClase.TabIndex = 19;
            this.labelCostoClase.Text = "Costo por clase:";
            // 
            // textBoxCantMax
            // 
            this.textBoxCantMax.Location = new System.Drawing.Point(563, 389);
            this.textBoxCantMax.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxCantMax.Name = "textBoxCantMax";
            this.textBoxCantMax.Size = new System.Drawing.Size(172, 38);
            this.textBoxCantMax.TabIndex = 18;
            // 
            // labelCantMax
            // 
            this.labelCantMax.AutoSize = true;
            this.labelCantMax.Location = new System.Drawing.Point(64, 396);
            this.labelCantMax.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.labelCantMax.Name = "labelCantMax";
            this.labelCantMax.Size = new System.Drawing.Size(463, 32);
            this.labelCantMax.TabIndex = 17;
            this.labelCantMax.Text = "Cantidad Maxima de Pariticipantes:";
            // 
            // textBoxNombreAct
            // 
            this.textBoxNombreAct.Location = new System.Drawing.Point(563, 262);
            this.textBoxNombreAct.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxNombreAct.Name = "textBoxNombreAct";
            this.textBoxNombreAct.Size = new System.Drawing.Size(401, 38);
            this.textBoxNombreAct.TabIndex = 16;
            // 
            // textBoxCodAct
            // 
            this.textBoxCodAct.Location = new System.Drawing.Point(563, 150);
            this.textBoxCodAct.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxCodAct.Name = "textBoxCodAct";
            this.textBoxCodAct.Size = new System.Drawing.Size(175, 38);
            this.textBoxCodAct.TabIndex = 15;
            // 
            // labelCodigoAct
            // 
            this.labelCodigoAct.AutoSize = true;
            this.labelCodigoAct.Location = new System.Drawing.Point(64, 150);
            this.labelCodigoAct.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.labelCodigoAct.Name = "labelCodigoAct";
            this.labelCodigoAct.Size = new System.Drawing.Size(269, 32);
            this.labelCodigoAct.TabIndex = 14;
            this.labelCodigoAct.Text = "Codigo de Actividad";
            // 
            // labelNombreAct
            // 
            this.labelNombreAct.AutoSize = true;
            this.labelNombreAct.Location = new System.Drawing.Point(64, 269);
            this.labelNombreAct.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.labelNombreAct.Name = "labelNombreAct";
            this.labelNombreAct.Size = new System.Drawing.Size(316, 32);
            this.labelNombreAct.TabIndex = 13;
            this.labelNombreAct.Text = "Nombre de la Actividad:";
            // 
            // buttonCrearActividad
            // 
            this.buttonCrearActividad.Location = new System.Drawing.Point(1731, 930);
            this.buttonCrearActividad.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonCrearActividad.Name = "buttonCrearActividad";
            this.buttonCrearActividad.Size = new System.Drawing.Size(336, 91);
            this.buttonCrearActividad.TabIndex = 26;
            this.buttonCrearActividad.Text = "Confirmar";
            this.buttonCrearActividad.UseVisualStyleBackColor = true;
            this.buttonCrearActividad.Click += new System.EventHandler(this.buttonCrearActividad_Click);
            // 
            // buttonVolverAct
            // 
            this.buttonVolverAct.Location = new System.Drawing.Point(70, 948);
            this.buttonVolverAct.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonVolverAct.Name = "buttonVolverAct";
            this.buttonVolverAct.Size = new System.Drawing.Size(336, 55);
            this.buttonVolverAct.TabIndex = 27;
            this.buttonVolverAct.Text = "Atras";
            this.buttonVolverAct.UseVisualStyleBackColor = true;
            this.buttonVolverAct.Click += new System.EventHandler(this.buttonVolverAct_Click);
            // 
            // listBoxHorarios
            // 
            this.listBoxHorarios.FormattingEnabled = true;
            this.listBoxHorarios.ItemHeight = 31;
            this.listBoxHorarios.Location = new System.Drawing.Point(1261, 111);
            this.listBoxHorarios.Name = "listBoxHorarios";
            this.listBoxHorarios.Size = new System.Drawing.Size(654, 376);
            this.listBoxHorarios.TabIndex = 28;
            // 
            // buttonNuevoHorario
            // 
            this.buttonNuevoHorario.Location = new System.Drawing.Point(1447, 539);
            this.buttonNuevoHorario.Name = "buttonNuevoHorario";
            this.buttonNuevoHorario.Size = new System.Drawing.Size(273, 59);
            this.buttonNuevoHorario.TabIndex = 29;
            this.buttonNuevoHorario.Text = "Nuevo Horario";
            this.buttonNuevoHorario.UseVisualStyleBackColor = true;
            this.buttonNuevoHorario.Click += new System.EventHandler(this.buttonNuevoHorario_Click);
            // 
            // DarDeAltaActividad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2133, 1073);
            this.Controls.Add(this.buttonNuevoHorario);
            this.Controls.Add(this.listBoxHorarios);
            this.Controls.Add(this.buttonVolverAct);
            this.Controls.Add(this.buttonCrearActividad);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelsigno);
            this.Controls.Add(this.textBoxCostoMensual);
            this.Controls.Add(this.textBoxCostoClase);
            this.Controls.Add(this.labelCostoMensual);
            this.Controls.Add(this.labelCostoClase);
            this.Controls.Add(this.textBoxCantMax);
            this.Controls.Add(this.labelCantMax);
            this.Controls.Add(this.textBoxNombreAct);
            this.Controls.Add(this.textBoxCodAct);
            this.Controls.Add(this.labelCodigoAct);
            this.Controls.Add(this.labelNombreAct);
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "DarDeAltaActividad";
            this.Text = "CrearActividad";
            this.Load += new System.EventHandler(this.DarDeAltaActividad_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelsigno;
        private System.Windows.Forms.TextBox textBoxCostoMensual;
        private System.Windows.Forms.TextBox textBoxCostoClase;
        private System.Windows.Forms.Label labelCostoMensual;
        private System.Windows.Forms.Label labelCostoClase;
        private System.Windows.Forms.TextBox textBoxCantMax;
        private System.Windows.Forms.Label labelCantMax;
        private System.Windows.Forms.TextBox textBoxNombreAct;
        private System.Windows.Forms.TextBox textBoxCodAct;
        private System.Windows.Forms.Label labelCodigoAct;
        private System.Windows.Forms.Label labelNombreAct;
        private System.Windows.Forms.Button buttonCrearActividad;
        private System.Windows.Forms.Button buttonVolverAct;
        private System.Windows.Forms.ListBox listBoxHorarios;
        private System.Windows.Forms.Button buttonNuevoHorario;
    }
}