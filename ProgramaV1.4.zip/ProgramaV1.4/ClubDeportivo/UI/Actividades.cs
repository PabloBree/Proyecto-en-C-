﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class Actividades : Form
    {
        private ClubDeportivo cd;
        
        public Actividades(ClubDeportivo c)
        {
            InitializeComponent();
            cd = c;
            listBoxActividades.DataSource = null;
            listBoxActividades.DataSource = cd.darActividadesDeportiva();
            listBoxActividades.ClearSelected();
        }

        private void buttonAgregarAct_Click(object sender, EventArgs e)
        {
            ActividadDeportiva actividad= null;
            DarDeAltaActividad act = new DarDeAltaActividad(cd);
            act.ShowDialog();
            actividad = act.darAct();

            

            if (actividad != null)
            {
                cd.AgregarActividadLista(actividad);
                listBoxActividades.DataSource = null;
                listBoxActividades.DataSource = cd.darActividadesDeportiva();
                listBoxActividades.ClearSelected();
            }
            else
                MessageBox.Show("La persona no fue creada");
        }

        private void buttonVolverMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Actividades_Load(object sender, EventArgs e)
        {

        }

        private void buttonEliminarAct_Click(object sender, EventArgs e)
        {
            ActividadDeportiva act = (ActividadDeportiva)listBoxActividades.SelectedItem;

            if (!cd.darListaSocios().Any())
                MessageBox.Show("No hay actividades cargadas");
            else
            {
                if (act == null)
                    MessageBox.Show("No hay socio seleccionado");
                else
                {
                    cd.EliminarActividades(act);

                    listBoxActividades.DataSource = null;
                    listBoxActividades.DataSource = cd.darListaSocios();
                    listBoxActividades.ClearSelected();
                }
            }
        }

        private void buttonModificarAct_Click(object sender, EventArgs e)
        {
            ModificarActividad ma = new ModificarActividad();
            ma.ShowDialog();
        }
    
    }
}
