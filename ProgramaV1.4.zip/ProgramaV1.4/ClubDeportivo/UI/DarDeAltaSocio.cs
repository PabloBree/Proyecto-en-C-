﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RN;

namespace UI
{
    public partial class DarDeAltaSocio : Form
    {
        private SocioActividades sA;
        private SocioClub sC;
        private Image fotoSocio;
        private ClubDeportivo cd;
        public DarDeAltaSocio(ClubDeportivo c)
        {
            InitializeComponent();
            cd = c;
            comboBoxTipo.Items.Add("SocioClub");
            comboBoxTipo.Items.Add("SocioActividades");
            comboBoxCategoria.Items.Add("Juvenil");
            comboBoxCategoria.Items.Add("Cadete");
            comboBoxCategoria.Items.Add("Profesional");
        }

        private void DarDeAlta_Load(object sender, EventArgs e)
        {

        }

        private void webCam1_CambioImagen()
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            webCam1.Start();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = webCam1.Imagen;
            fotoSocio = webCam1.Imagen;
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void comboBoxTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            
           
        }

        private void buttonAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonGenerarSocio_Click(object sender, EventArgs e)
        {
            String a, n, dir, email,tipo,cat;
            int dni, telefono, numS;
            tipo = comboBoxTipo.SelectedItem.ToString();
            a = textBoxApellido.Text;
            n = textBoxNombre.Text;
            dir = textBoxDir.Text;
            email = textBoxEmail.Text;
            dni = int.Parse(textBoxDNI.Text);
            telefono = int.Parse(textBoxTelefono.Text);
            numS = cd.DarNumeroIdSocio();
            cat = comboBoxCategoria.SelectedItem.ToString();
           

            if (tipo == "SocioClub")
            {
                sC = new SocioClub(a, n, dir, dni, email, telefono, fotoSocio, numS,cat);
            }else if (tipo == "SocioActividades")
            {
                sA = new SocioActividades(a, n, dir, dni, email, telefono, fotoSocio, numS,cat);
            }

            if ((sC != null) || (sA != null))
                MessageBox.Show("Carga exitosa");
            else
                MessageBox.Show("Error en la carga");

        }


        public SocioClub darSocioClub()
        {
            return sC;
        }

        public SocioActividades darSocioActividades()
        {
            return sA;
        }
    }
}
