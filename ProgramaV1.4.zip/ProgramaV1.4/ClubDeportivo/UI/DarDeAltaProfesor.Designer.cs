﻿namespace UI
{
    partial class DarDeAltaProfesor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxDNI = new System.Windows.Forms.TextBox();
            this.textBoxNombre = new System.Windows.Forms.TextBox();
            this.textBoxApellido = new System.Windows.Forms.TextBox();
            this.textBoxEMAIL = new System.Windows.Forms.TextBox();
            this.textBoxTelefono = new System.Windows.Forms.TextBox();
            this.buttonAtras = new System.Windows.Forms.Button();
            this.webCamProfesor = new WebCAM.WebCam();
            this.pictureBoxProfesor = new System.Windows.Forms.PictureBox();
            this.buttonIniciar = new System.Windows.Forms.Button();
            this.buttonCapturar = new System.Windows.Forms.Button();
            this.buttonGenerar = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxDireccion = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProfesor)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(141, 122);
            this.label1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "DNI";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 241);
            this.label2.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(141, 358);
            this.label3.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Apellido";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(141, 565);
            this.label4.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 32);
            this.label4.TabIndex = 3;
            this.label4.Text = "Email";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(128, 663);
            this.label5.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 32);
            this.label5.TabIndex = 4;
            this.label5.Text = "Teléfono";
            // 
            // textBoxDNI
            // 
            this.textBoxDNI.Location = new System.Drawing.Point(341, 114);
            this.textBoxDNI.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxDNI.Name = "textBoxDNI";
            this.textBoxDNI.Size = new System.Drawing.Size(284, 38);
            this.textBoxDNI.TabIndex = 5;
            // 
            // textBoxNombre
            // 
            this.textBoxNombre.Location = new System.Drawing.Point(341, 234);
            this.textBoxNombre.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxNombre.Name = "textBoxNombre";
            this.textBoxNombre.Size = new System.Drawing.Size(284, 38);
            this.textBoxNombre.TabIndex = 6;
            // 
            // textBoxApellido
            // 
            this.textBoxApellido.Location = new System.Drawing.Point(341, 341);
            this.textBoxApellido.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxApellido.Name = "textBoxApellido";
            this.textBoxApellido.Size = new System.Drawing.Size(284, 38);
            this.textBoxApellido.TabIndex = 7;
            // 
            // textBoxEMAIL
            // 
            this.textBoxEMAIL.Location = new System.Drawing.Point(341, 558);
            this.textBoxEMAIL.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxEMAIL.Name = "textBoxEMAIL";
            this.textBoxEMAIL.Size = new System.Drawing.Size(284, 38);
            this.textBoxEMAIL.TabIndex = 8;
            // 
            // textBoxTelefono
            // 
            this.textBoxTelefono.Location = new System.Drawing.Point(341, 663);
            this.textBoxTelefono.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxTelefono.Name = "textBoxTelefono";
            this.textBoxTelefono.Size = new System.Drawing.Size(284, 38);
            this.textBoxTelefono.TabIndex = 9;
            // 
            // buttonAtras
            // 
            this.buttonAtras.Location = new System.Drawing.Point(59, 744);
            this.buttonAtras.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonAtras.Name = "buttonAtras";
            this.buttonAtras.Size = new System.Drawing.Size(200, 55);
            this.buttonAtras.TabIndex = 10;
            this.buttonAtras.Text = "Atras";
            this.buttonAtras.UseVisualStyleBackColor = true;
            this.buttonAtras.Click += new System.EventHandler(this.buttonAtras_Click);
            // 
            // webCamProfesor
            // 
            this.webCamProfesor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.webCamProfesor.Imagen = null;
            this.webCamProfesor.Location = new System.Drawing.Point(787, 160);
            this.webCamProfesor.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.webCamProfesor.MilisegundosCaptura = 100;
            this.webCamProfesor.Name = "webCamProfesor";
            this.webCamProfesor.Size = new System.Drawing.Size(512, 372);
            this.webCamProfesor.TabIndex = 11;
            // 
            // pictureBoxProfesor
            // 
            this.pictureBoxProfesor.Location = new System.Drawing.Point(1339, 160);
            this.pictureBoxProfesor.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.pictureBoxProfesor.Name = "pictureBoxProfesor";
            this.pictureBoxProfesor.Size = new System.Drawing.Size(512, 372);
            this.pictureBoxProfesor.TabIndex = 12;
            this.pictureBoxProfesor.TabStop = false;
            // 
            // buttonIniciar
            // 
            this.buttonIniciar.Location = new System.Drawing.Point(941, 606);
            this.buttonIniciar.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonIniciar.Name = "buttonIniciar";
            this.buttonIniciar.Size = new System.Drawing.Size(200, 55);
            this.buttonIniciar.TabIndex = 13;
            this.buttonIniciar.Text = "Iniciar";
            this.buttonIniciar.UseVisualStyleBackColor = true;
            this.buttonIniciar.Click += new System.EventHandler(this.buttonIniciar_Click);
            // 
            // buttonCapturar
            // 
            this.buttonCapturar.Location = new System.Drawing.Point(1509, 606);
            this.buttonCapturar.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonCapturar.Name = "buttonCapturar";
            this.buttonCapturar.Size = new System.Drawing.Size(200, 55);
            this.buttonCapturar.TabIndex = 14;
            this.buttonCapturar.Text = "Capturar";
            this.buttonCapturar.UseVisualStyleBackColor = true;
            this.buttonCapturar.Click += new System.EventHandler(this.buttonCapturar_Click);
            // 
            // buttonGenerar
            // 
            this.buttonGenerar.Location = new System.Drawing.Point(1651, 744);
            this.buttonGenerar.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonGenerar.Name = "buttonGenerar";
            this.buttonGenerar.Size = new System.Drawing.Size(200, 55);
            this.buttonGenerar.TabIndex = 15;
            this.buttonGenerar.Text = "Generar";
            this.buttonGenerar.UseVisualStyleBackColor = true;
            this.buttonGenerar.Click += new System.EventHandler(this.buttonGenerar_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(141, 455);
            this.label6.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 32);
            this.label6.TabIndex = 16;
            this.label6.Text = "Dirección";
            // 
            // textBoxDireccion
            // 
            this.textBoxDireccion.Location = new System.Drawing.Point(341, 455);
            this.textBoxDireccion.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBoxDireccion.Name = "textBoxDireccion";
            this.textBoxDireccion.Size = new System.Drawing.Size(284, 38);
            this.textBoxDireccion.TabIndex = 17;
            // 
            // DarDeAltaProfesor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1888, 854);
            this.Controls.Add(this.textBoxDireccion);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonGenerar);
            this.Controls.Add(this.buttonCapturar);
            this.Controls.Add(this.buttonIniciar);
            this.Controls.Add(this.pictureBoxProfesor);
            this.Controls.Add(this.webCamProfesor);
            this.Controls.Add(this.buttonAtras);
            this.Controls.Add(this.textBoxTelefono);
            this.Controls.Add(this.textBoxEMAIL);
            this.Controls.Add(this.textBoxApellido);
            this.Controls.Add(this.textBoxNombre);
            this.Controls.Add(this.textBoxDNI);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "DarDeAltaProfesor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DarDeAltaProfesor";
            this.Load += new System.EventHandler(this.DarDeAltaProfesor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProfesor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxDNI;
        private System.Windows.Forms.TextBox textBoxNombre;
        private System.Windows.Forms.TextBox textBoxApellido;
        private System.Windows.Forms.TextBox textBoxEMAIL;
        private System.Windows.Forms.TextBox textBoxTelefono;
        private System.Windows.Forms.Button buttonAtras;
        private WebCAM.WebCam webCamProfesor;
        private System.Windows.Forms.PictureBox pictureBoxProfesor;
        private System.Windows.Forms.Button buttonIniciar;
        private System.Windows.Forms.Button buttonCapturar;
        private System.Windows.Forms.Button buttonGenerar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxDireccion;
    }
}